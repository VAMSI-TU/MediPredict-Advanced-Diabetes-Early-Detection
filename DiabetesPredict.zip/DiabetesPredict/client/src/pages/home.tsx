import { useState } from "react";
import { DiabetesForm } from "@/components/diabetes-form";
import { RiskReport } from "@/components/risk-report";
import { DiabetesInput, PredictionResult } from "@/lib/mockPrediction";
import { Activity, ShieldCheck, HeartPulse, Info } from "lucide-react";
import bgImage from "@assets/generated_images/abstract_medical_background_with_dna_helix_and_clean_geometry.png";

export default function Home() {
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [inputData, setInputData] = useState<DiabetesInput | null>(null);

  const handleResult = (res: PredictionResult, data: DiabetesInput) => {
    setResult(res);
    setInputData(data);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReset = () => {
    setResult(null);
    setInputData(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 pb-20">
      {/* Hero Background */}
      <div className="absolute top-0 left-0 w-full h-[600px] overflow-hidden z-0">
        <img 
          src={bgImage} 
          alt="Medical Background" 
          className="w-full h-full object-cover opacity-20 mask-image-b-gradient" 
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-50/50 to-slate-50"></div>
      </div>

      {/* Navbar */}
      <header className="relative z-10 border-b bg-white/80 backdrop-blur-md sticky top-0">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary text-white p-1.5 rounded-lg">
              <Activity className="h-6 w-6" />
            </div>
            <span className="font-heading font-bold text-xl text-primary tracking-tight">
              MediPredict
            </span>
          </div>
          <nav className="hidden md:flex gap-6 text-sm font-medium text-muted-foreground">
            <a href="#" className="hover:text-primary transition-colors">About</a>
            <a href="#" className="hover:text-primary transition-colors">Methodology</a>
            <a href="#" className="hover:text-primary transition-colors">Contact</a>
          </nav>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 pt-12 md:pt-20">
        {!result ? (
          <div className="grid lg:grid-cols-12 gap-12">
            {/* Left Column: Intro Text */}
            <div className="lg:col-span-5 space-y-8 pt-4">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold uppercase tracking-wide">
                  <ShieldCheck className="w-3 h-3" />
                  AI-Powered Risk Assessment
                </div>
                <h1 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 leading-tight">
                  Advanced Diabetes <br/>
                  <span className="text-primary">Early Detection</span>
                </h1>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Utilizing logistic regression models trained on clinical datasets to provide preliminary diabetes risk assessments. Fast, private, and designed for clarity.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4">
                <FeatureCard 
                  icon={<HeartPulse className="w-5 h-5 text-primary" />}
                  title="Clinical Precision"
                  desc="Modeled on standard medical parameters"
                />
                 <FeatureCard 
                  icon={<ShieldCheck className="w-5 h-5 text-primary" />}
                  title="Privacy First"
                  desc="All analysis happens securely"
                />
              </div>
            </div>

            {/* Right Column: Form */}
            <div className="lg:col-span-7">
              <DiabetesForm onResult={handleResult} />
            </div>
          </div>
        ) : (
          <RiskReport 
            result={result} 
            data={inputData!} 
            onReset={handleReset} 
          />
        )}
      </main>

      <footer className="relative z-10 mt-24 border-t bg-white py-12">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <div className="flex justify-center items-center gap-2 mb-4">
            <Activity className="h-5 w-5 text-primary/50" />
            <span className="font-heading font-bold text-slate-700">MediPredict</span>
          </div>
          <p className="max-w-2xl mx-auto mb-4">
            This tool uses a machine learning model (Logistic Regression) trained on the Pima Indians Diabetes Database. 
            It is intended for educational and informational purposes only.
          </p>
          <p className="font-bold text-slate-900">
            Not a substitute for professional medical advice, diagnosis, or treatment.
          </p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="p-4 rounded-xl bg-white border shadow-sm">
      <div className="mb-3">{icon}</div>
      <h3 className="font-bold text-slate-900 mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}
