// Function to simulate the backend Logistic Regression model
// In a real app, this would be a fetch call to the Python backend
// e.g., await fetch('/api/predict', { method: 'POST', body: JSON.stringify(data) })

export interface DiabetesInput {
  pregnancies: number;
  glucose: number;
  bloodPressure: number;
  skinThickness: number;
  insulin: number;
  bmi: number;
  diabetesPedigreeFunction: number;
  age: number;
  name: string;
}

export interface PredictionResult {
  riskLevel: "Low" | "Medium" | "High";
  probability: number; // 0 to 100
  interpretation: string;
  timestamp: string;
}

export const predictDiabetesRisk = async (data: DiabetesInput): Promise<PredictionResult> => {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1500));

  // Heuristic logic to mimic a trained model's output for the prototype
  // This is NOT a real medical diagnosis tool
  
  let score = 0;

  // Glucose is the strongest predictor
  if (data.glucose > 140) score += 40;
  else if (data.glucose > 100) score += 15;

  // BMI
  if (data.bmi > 30) score += 20;
  else if (data.bmi > 25) score += 10;

  // Age
  if (data.age > 50) score += 15;
  else if (data.age > 35) score += 5;

  // Pedigree function (family history impact)
  if (data.diabetesPedigreeFunction > 0.8) score += 15;
  else if (data.diabetesPedigreeFunction > 0.5) score += 5;

  // Insulin
  if (data.insulin > 150) score += 10;

  // Pregnancies (Gestational diabetes history factor)
  if (data.pregnancies > 4) score += 5;

  // Blood Pressure
  if (data.bloodPressure > 90) score += 5;

  // Cap score at 98 (no model is 100% certain)
  // Add some randomness to simulate model variance
  const randomFactor = Math.random() * 5 - 2.5; // +/- 2.5%
  let finalScore = Math.min(98, Math.max(2, score + randomFactor));

  let riskLevel: "Low" | "Medium" | "High" = "Low";
  let interpretation = "Your results suggest a low risk of diabetes. Maintain a healthy lifestyle.";

  if (finalScore > 65) {
    riskLevel = "High";
    interpretation = "Your profile indicates a high likelihood of diabetes. Immediate consultation with a healthcare provider is recommended.";
  } else if (finalScore > 35) {
    riskLevel = "Medium";
    interpretation = "You are in a pre-diabetic or moderate risk range. Lifestyle monitoring is advised.";
  }

  return {
    riskLevel,
    probability: parseFloat(finalScore.toFixed(1)),
    interpretation,
    timestamp: new Date().toISOString(),
  };
};
