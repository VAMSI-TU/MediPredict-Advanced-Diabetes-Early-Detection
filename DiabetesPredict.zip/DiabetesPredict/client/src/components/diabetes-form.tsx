import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Loader2, Activity, ChevronRight, CheckCircle2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DiabetesInput, predictDiabetesRisk, PredictionResult } from "@/lib/mockPrediction";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  pregnancies: z.coerce.number().min(0).max(20),
  glucose: z.coerce.number().min(0).max(300),
  bloodPressure: z.coerce.number().min(0).max(200),
  skinThickness: z.coerce.number().min(0).max(100),
  insulin: z.coerce.number().min(0).max(900),
  bmi: z.coerce.number().min(0).max(70),
  diabetesPedigreeFunction: z.coerce.number().min(0).max(2.5),
  age: z.coerce.number().min(1).max(120),
});

interface DiabetesFormProps {
  onResult: (result: PredictionResult, data: DiabetesInput) => void;
}

export function DiabetesForm({ onResult }: DiabetesFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      pregnancies: 0,
      glucose: 100,
      bloodPressure: 70,
      skinThickness: 20,
      insulin: 79,
      bmi: 25,
      diabetesPedigreeFunction: 0.5,
      age: 30,
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    try {
      const result = await predictDiabetesRisk(values);
      onResult(result, values);
    } catch (error) {
      console.error("Prediction failed", error);
    } finally {
      setIsLoading(false);
    }
  }

  const nextStep = async () => {
    // Trigger validation for current step fields only if needed
    // keeping it simple for now
    setStep(step + 1);
  };

  const prevStep = () => setStep(step - 1);

  return (
    <Card className="w-full max-w-2xl mx-auto border-t-4 border-t-primary shadow-lg bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl text-primary font-heading font-bold">
              Patient Assessment
            </CardTitle>
            <CardDescription>
              Enter clinical parameters for AI analysis
            </CardDescription>
          </div>
          <div className="flex items-center gap-1 text-sm font-mono text-muted-foreground bg-muted px-3 py-1 rounded-full">
            <Activity className="h-4 w-4" />
            <span>Step {step}/3</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-6"
              >
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="name">Patient Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter full name"
                      {...form.register("name")}
                      className="h-12 text-lg"
                    />
                    {form.formState.errors.name && (
                      <span className="text-destructive text-sm">{form.formState.errors.name.message}</span>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="age">Age (Years)</Label>
                    <div className="flex items-center gap-4">
                      <Input
                        id="age"
                        type="number"
                        {...form.register("age")}
                        className="h-12 font-mono text-lg"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="pregnancies">Pregnancies</Label>
                    <Input
                      id="pregnancies"
                      type="number"
                      {...form.register("pregnancies")}
                      className="h-12 font-mono text-lg"
                    />
                    <p className="text-xs text-muted-foreground">Number of times pregnant</p>
                  </div>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-6"
              >
                 <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="glucose" className="flex justify-between">
                      <span>Glucose Level</span>
                      <span className="text-muted-foreground font-mono text-xs">mg/dL</span>
                    </Label>
                    <Input
                      id="glucose"
                      type="number"
                      {...form.register("glucose")}
                      className={cn(
                        "h-12 font-mono text-lg border-l-4", 
                        form.watch("glucose") > 140 ? "border-l-destructive" : "border-l-primary"
                      )}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bloodPressure" className="flex justify-between">
                      <span>Blood Pressure</span>
                      <span className="text-muted-foreground font-mono text-xs">mm Hg</span>
                    </Label>
                    <Input
                      id="bloodPressure"
                      type="number"
                      {...form.register("bloodPressure")}
                      className="h-12 font-mono text-lg"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="insulin" className="flex justify-between">
                      <span>Insulin</span>
                      <span className="text-muted-foreground font-mono text-xs">mu U/ml</span>
                    </Label>
                    <Input
                      id="insulin"
                      type="number"
                      {...form.register("insulin")}
                      className="h-12 font-mono text-lg"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="skinThickness" className="flex justify-between">
                      <span>Skin Thickness</span>
                      <span className="text-muted-foreground font-mono text-xs">mm</span>
                    </Label>
                    <Input
                      id="skinThickness"
                      type="number"
                      {...form.register("skinThickness")}
                      className="h-12 font-mono text-lg"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-6"
              >
                <div className="grid gap-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="bmi">BMI (Body Mass Index)</Label>
                      <span className="font-mono text-lg font-bold text-primary">{form.watch("bmi")}</span>
                    </div>
                    <Slider 
                      defaultValue={[25]} 
                      max={60} 
                      step={0.1} 
                      value={[form.watch("bmi")]}
                      onValueChange={(val) => form.setValue("bmi", val[0])}
                      className="py-4"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground font-mono">
                      <span>Underweight</span>
                      <span>Healthy</span>
                      <span>Overweight</span>
                      <span>Obese</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="diabetesPedigreeFunction">Diabetes Pedigree Function</Label>
                    <Input
                      id="diabetesPedigreeFunction"
                      type="number"
                      step="0.01"
                      {...form.register("diabetesPedigreeFunction")}
                      className="h-12 font-mono text-lg"
                    />
                    <p className="text-xs text-muted-foreground">
                      A function which scores likelihood of diabetes based on family history
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex justify-between pt-6 border-t mt-8">
            {step > 1 ? (
              <Button type="button" variant="outline" onClick={prevStep}>
                Back
              </Button>
            ) : (
              <div />
            )}

            {step < 3 ? (
              <Button type="button" onClick={nextStep} className="px-8">
                Next Step <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button type="submit" disabled={isLoading} className="px-8 bg-primary hover:bg-primary/90 text-white">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    Generate Report <Activity className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
