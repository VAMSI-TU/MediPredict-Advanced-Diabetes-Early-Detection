import { motion } from "framer-motion";
import { PredictionResult, DiabetesInput } from "@/lib/mockPrediction";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Printer, Share2, RefreshCcw, AlertCircle, CheckCircle, HelpCircle } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface RiskReportProps {
  result: PredictionResult;
  data: DiabetesInput;
  onReset: () => void;
}

export function RiskReport({ result, data, onReset }: RiskReportProps) {
  const isHighRisk = result.riskLevel === "High";
  const isMediumRisk = result.riskLevel === "Medium";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="w-full max-w-3xl mx-auto"
    >
      <Card className="overflow-hidden border-t-8 border-t-primary shadow-2xl print:shadow-none">
        <div className="bg-slate-50 p-4 border-b flex justify-between items-center print:hidden">
          <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
            Report ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}
          </span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="w-4 h-4 mr-2" /> Print
            </Button>
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" /> Share
            </Button>
          </div>
        </div>

        <CardContent className="p-8 report-paper min-h-[600px]">
          {/* Header */}
          <div className="flex justify-between items-start mb-8 pb-8 border-b-2 border-primary/20">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 font-heading">MEDICAL REPORT</h1>
              <p className="text-primary font-medium">Diabetes Risk Assessment</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Date</p>
              <p className="font-mono text-slate-900">{new Date().toLocaleDateString()}</p>
            </div>
          </div>

          {/* Patient Info */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Patient Name</p>
              <p className="text-xl font-semibold text-slate-900">{data.name}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Age</p>
              <p className="text-xl font-mono text-slate-900">{data.age} Years</p>
            </div>
          </div>

          {/* Main Result Block */}
          <div className={`
            p-6 rounded-lg border-l-4 mb-8
            ${isHighRisk 
              ? "bg-red-50 border-red-500 text-red-900" 
              : isMediumRisk 
                ? "bg-orange-50 border-orange-500 text-orange-900" 
                : "bg-teal-50 border-teal-500 text-teal-900"
            }
          `}>
            <div className="flex items-start gap-4">
              {isHighRisk ? (
                <AlertCircle className="w-8 h-8 text-red-500 mt-1" />
              ) : isMediumRisk ? (
                <HelpCircle className="w-8 h-8 text-orange-500 mt-1" />
              ) : (
                <CheckCircle className="w-8 h-8 text-teal-500 mt-1" />
              )}
              <div>
                <h3 className="text-lg font-bold uppercase mb-1">Assessment Result: {result.riskLevel} Risk</h3>
                <p className="text-sm opacity-90 mb-4">{result.interpretation}</p>
                <div className="flex items-end gap-2">
                  <span className="text-4xl font-bold font-mono">{result.probability}%</span>
                  <span className="text-sm mb-1 font-medium opacity-75">Estimated Probability</span>
                </div>
              </div>
            </div>
          </div>

          {/* Clinical Parameters Table */}
          <div className="mb-8">
            <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b pb-2">Clinical Parameters</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-y-6 gap-x-4">
              <ParameterItem label="Glucose" value={data.glucose} unit="mg/dL" />
              <ParameterItem label="Blood Pressure" value={data.bloodPressure} unit="mm Hg" />
              <ParameterItem label="BMI" value={data.bmi} unit="kg/m²" />
              <ParameterItem label="Insulin" value={data.insulin} unit="mu U/ml" />
              <ParameterItem label="Pregnancies" value={data.pregnancies} unit="" />
              <ParameterItem label="Skin Thickness" value={data.skinThickness} unit="mm" />
              <ParameterItem label="Pedigree Func" value={data.diabetesPedigreeFunction} unit="" />
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-slate-100 p-6 rounded-lg">
            <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">Recommendations</h4>
            <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
              <li>Maintain a balanced diet rich in whole grains and vegetables.</li>
              <li>Regular physical activity (at least 30 mins/day).</li>
              <li>Monitor blood sugar levels regularly.</li>
              {isHighRisk && <li className="font-bold text-red-600">Consult a diabetologist immediately for further evaluation.</li>}
            </ul>
          </div>

          {/* Disclaimer Footer (On the paper) */}
          <div className="mt-12 pt-4 border-t border-dashed text-[10px] text-muted-foreground text-center">
            <p>DISCLAIMER: This report is generated by an AI-based prototype model (Logistic Regression). It is NOT a substitute for professional medical diagnosis. Please consult a certified healthcare professional for accurate medical advice.</p>
            <p className="mt-1 font-mono">Generated via MediPredict • AIIMS/CMC Vellore Style Report</p>
          </div>

        </CardContent>
        
        <div className="p-4 bg-slate-50 border-t text-center print:hidden">
          <Button onClick={onReset} variant="ghost" className="text-primary hover:text-primary/80">
            <RefreshCcw className="w-4 h-4 mr-2" /> Start New Assessment
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}

function ParameterItem({ label, value, unit }: { label: string, value: string | number, unit: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground uppercase mb-1">{label}</p>
      <p className="font-mono font-medium text-slate-900">
        {value} <span className="text-xs text-muted-foreground">{unit}</span>
      </p>
    </div>
  );
}
